<?php

use Restserver\Libraries\REST_Controller;

defined('BASEPATH') or exit('No direct script access allowed');

require APPPATH . '/libraries/REST_Controller.php';
//require APPPATH . '/libraries/Format.php';

class Restaurant extends REST_Controller
{

    function __construct($config = 'rest')
    {
        parent::__construct($config);
        $this->load->database();
    }

    //GET index
    function index_get()
    {
        $id = $this->get('restaurant_id');
        if ($id == 'all') {
            $sql = "select * from restaurant_master";
            $data = $this->db->query($sql)->result_array();
             //$count = $this->db->count_all_results('restaurant_master');
        } else {
            //$this->db->where('restaurant_id', $id);
            $sql = "select * from restaurant_master where restaurant_id=$id";
            $data = $this->db->query($sql)->result_array();
            //$count = $this->db->count_all_results();
        }

        if ($data) {
            $this->response([
                'status' => true,
                //'count' => $count,
                'data' => $data
            ], REST_Controller::HTTP_OK);
        } else {
            // Set the response and exit
            $this->response([
                'status' => FALSE,
                'message' => 'No data were found'
            ], REST_Controller::HTTP_NOT_FOUND); // NOT_FOUND (404) being the HTTP response code
        }
    }

    //GET restaurantPriceRange
    function restaurantPriceRange_get()
    {
        //$id = $this->get('restaurant_id');
        $AtLeastHavingXMenuWithinPriceRange = $this->get('AtLeastHavingXMenuWithinPriceRange');
        $TopNumberOfResto = $this->get('TopNumberOfResto');
        $MinPrice = $this->get('MinPrice');
        $MaxPrice = $this->get('MaxPrice');
        if (
            $AtLeastHavingXMenuWithinPriceRange != ''
            and $TopNumberOfResto != ''
            and $MinPrice != ''
            and $MaxPrice != ''
        ) {
            $sql = "
            SELECT a.restaurantname from restaurant_master a
            INNER JOIN restaurant_menu b ON a.restaurant_id=b.restaurant_id
            WHERE b.price BETWEEN '$MinPrice' AND '$MaxPrice'
            GROUP BY a.restaurant_id
            HAVING COUNT(b.dishname) >= $AtLeastHavingXMenuWithinPriceRange
            ORDER BY b.price
            LIMIT $TopNumberOfResto";

            $data = $this->db->query($sql)->result_array();
            //$count = $this->db->count_all_results($data);
        }

        if ($data) {
            $this->response([
                'status' => true,
                //'count' => $count,
                'data' => $data
            ], REST_Controller::HTTP_OK);
        } else {
            // Set the response and exit
            $this->response([
                'status' => FALSE,
                'message' => 'No data were found'
            ], REST_Controller::HTTP_NOT_FOUND); // NOT_FOUND (404) being the HTTP response code
        }
    }

    //GET SearchRestaurantsDishes
    function SearchRestaurantsDishes_get()
    {
        //$id = $this->get('restaurant_id');
        $RestaurantName = $this->get('RestaurantName');
        $DishesName = $this->get('DishesName');
        if (
            $RestaurantName != ''
            and $DishesName != ''
        ) {
            $sql = "
            SELECT a.restaurantName,b.dishName,b.price from restaurant_master a
            INNER JOIN restaurant_menu b ON a.restaurant_id=b.restaurant_id
            WHERE a.restaurantName LIKE '%$RestaurantName%' 
            OR b.dishName LIKE '%$DishesName%'
            ORDER BY 1,2    
            ";

            $data = $this->db->query($sql)->result_array();
        }

        if ($data) {
            $this->response([
                'status' => true,
                //'count' => $count,
                'data' => $data
            ], REST_Controller::HTTP_OK);
        } else {
            // Set the response and exit
            $this->response([
                'status' => FALSE,
                'message' => 'No data were found'
            ], REST_Controller::HTTP_NOT_FOUND); // NOT_FOUND (404) being the HTTP response code
        }
    }

    //GET ProcessUserPurchasing
    function ProcessUserPurchasing_get()
    {
        $id = $this->get('user_id');
        if ($id != '') {
            $sql = "CALL ProcessUserPurchasing5($id)";
            $data = $this->db->query($sql)->result();
        }

        if ($data) {
            $this->response([
                'status' => true,
                //'count' => $count,
                'data' => $data
            ], REST_Controller::HTTP_OK);
        } else {
            // Set the response and exit
            $this->response([
                'status' => FALSE,
                'message' => 'No data were found'
            ], REST_Controller::HTTP_NOT_FOUND); // NOT_FOUND (404) being the HTTP response code
        }
    }
}
